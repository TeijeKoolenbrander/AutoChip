// Create a sequence detector.
// Ports:
//   clk            : clock; all state changes happen on its rising edge
//   reset_n        : active-low ASYNCHRONOUS reset
//   enable         : data is sampled only on rising edges where enable is 1
//   data           : 3-bit input value
//   sequence_found : output
//
// The detector looks for this sequence of 8 consecutive sampled values,
// oldest first:
//   3'b001, 3'b101, 3'b110, 3'b000, 3'b110, 3'b110, 3'b011, 3'b101
//
// Behavior:
//   - On a rising edge of clk where enable is 1, data is sampled. If the 8 most
//     recently sampled values, including the one just sampled, match the
//     sequence, sequence_found becomes 1 after that edge. Otherwise it becomes 0.
//   - On a rising edge of clk where enable is 0, data is ignored, the detector's
//     progress through the sequence is kept, and sequence_found becomes 0.
//   - So sequence_found is 1 for exactly one clock cycle per detection.
//   - Any 8 consecutive sampled values that match count as a detection, even if
//     they overlap an earlier partial or complete match.
//   - Disabled edges do not break a sequence: values sampled before and after a
//     run of disabled edges are still consecutive samples.
//   - When reset_n is 0, all state is cleared immediately and sequence_found is 0.
//     Values sampled before a reset never count toward a match.
//
// Implementation hint: keep the last 8 sampled values in a 24-bit shift
// register, newest value in the low 3 bits. On every enabled edge, compare the
// shifted value that INCLUDES the data being sampled on this edge, for example
// {history[20:0], data}, against the full 24-bit sequence. Do not use a
// circular buffer with a write index, and do not compare against a register
// that is being written with a nonblocking assignment on the same edge.

module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output       sequence_found
);

endmodule
