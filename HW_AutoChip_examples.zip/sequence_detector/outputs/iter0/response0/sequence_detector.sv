module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output reg   sequence_found
);
    reg [23:0] history;

    // Define the target sequence
    localparam [23:0] SEQUENCE = 24'b001101100110110101;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            history <= 24'b0;
            sequence_found <= 0;
        end else if (enable) begin
            // Shift in the new data
            history <= {history[20:0], data};
            // Check for the sequence match
            if (history == SEQUENCE) begin
                sequence_found <= 1;
            end else begin
                sequence_found <= 0;
            end
        end else begin
            // Maintain the state of sequence_found if enable is low
            sequence_found <= 0;
        end
    end
endmodule
