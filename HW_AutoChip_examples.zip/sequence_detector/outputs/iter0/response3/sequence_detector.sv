module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output reg   sequence_found
);

    reg [23:0] history; // 8 sampled values of 3 bits each
    // 3'b001, 3'b101, 3'b110, 3'b000, 3'b110, 3'b110, 3'b011, 3'b101
    localparam [23:0] TARGET_SEQUENCE = 24'b001101100110110101;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            history <= 24'b0;
            sequence_found <= 0;
        end else if (enable) begin
            history <= {history[20:0], data}; // Shift in the new data
            sequence_found <= (history == TARGET_SEQUENCE); // Compare with target sequence
        end else begin
            sequence_found <= 0; // If not enabled, reset output
        end
    end

endmodule
