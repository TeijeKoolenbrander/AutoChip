module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output reg   sequence_found
);

reg [23:0] history; // 8 values of 3 bits each, total 24 bits
reg [23:0] sequence = {3'b101, 3'b011, 3'b110, 3'b110, 3'b000, 3'b110, 3'b101, 3'b001}; // The target sequence

always @(posedge clk or negedge reset_n) begin
    if (!reset_n) begin
        history <= 24'b0;
        sequence_found <= 0;
    end else begin
        if (enable) begin
            history <= {history[20:0], data}; // Shift in the new data
            if (history == sequence) begin
                sequence_found <= 1;
            end else begin
                sequence_found <= 0;
            end
        end else begin
            sequence_found <= 0; // Ignore data inputs
        end
    end
end

endmodule
