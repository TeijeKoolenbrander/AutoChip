module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output reg   sequence_found
);

    reg [23:0] history; // 24-bit shift register for the last 8 sampled values

    // The target sequence for matching
    localparam SEQUENCE = 24'b001_101_110_000_110_110_011_101;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            history <= 24'b0;
            sequence_found <= 0;
        end else if (enable) begin
            history <= {history[20:0], data}; // Shift in the new data
            if (history == SEQUENCE) begin
                sequence_found <= 1; // Sequence found for one clock cycle
            end else begin
                sequence_found <= 0; // No sequence found
            end
        end else begin
            sequence_found <= 0; // When enable is low, ignore data and reset output
        end
    end

endmodule
