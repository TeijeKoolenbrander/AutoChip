module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output reg   sequence_found
);
    reg [23:0] history; // 8 samples, 3 bits each
    // The predefined expected sequence
    localparam [23:0] SEQ = 24'b001101100110110101;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            history <= 24'b0;
            sequence_found <= 0;
        end else if (enable) begin
            // Shift the history and insert the new data
            history <= {history[20:0], data};
            // Check for the sequence match on the current sample
            if (history == SEQ) begin
                sequence_found <= 1;
            end else begin
                sequence_found <= 0; // Reset the output if no match
            end
        end else begin
            // If not enabled, do not affect history or output
            sequence_found <= 0;
        end
    end
endmodule
