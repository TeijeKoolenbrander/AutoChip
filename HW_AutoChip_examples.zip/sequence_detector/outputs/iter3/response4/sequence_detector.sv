module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output reg   sequence_found
);
    reg [23:0] history; // 8 samples, 3 bits each

    // The predefined expected sequence
    localparam [23:0] SEQ = 24'b001101100110110101; // Correct sequence representation

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            history <= 24'b0;
            sequence_found <= 0;
        end else begin
            if (enable) begin
                // Shift in the new data
                history <= {history[20:0], data}; // Shift history, adding the new data
                // Check for the sequence match
                sequence_found <= (history == SEQ);
            end else begin
                // When enable is low, we maintain the current state
                sequence_found <= 0; // Only reset output if enable was low
            end
        end
    end
endmodule
