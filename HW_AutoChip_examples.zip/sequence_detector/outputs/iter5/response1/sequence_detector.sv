module sequence_detector (
    input        clk,
    input        reset_n,
    input        enable,
    input  [2:0] data,
    output reg   sequence_found
);
    reg [23:0] history; // 8 samples, 3 bits each

    // The predefined expected sequence for 8 samples
    localparam [23:0] SEQ = 24'b001101100110110101;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            history <= 24'b0;
            sequence_found <= 0;
        end else begin
            if (enable) begin
                // Shift the history and insert the new data
                history <= {history[20:0], data};
                // Check for the sequence match
                sequence_found <= (history == SEQ);
            end else begin
                // Retain sequence_found state if enable is low
                sequence_found <= sequence_found; 
            end
        end
    end
endmodule
