module tb;
    reg        clk = 1'b0;
    reg        reset_n = 1'b0;
    reg        enable = 1'b0;
    reg  [2:0] data = 3'b000;
    wire       sequence_found;

    // Target sequence, oldest value in the top bits
    localparam [23:0] TARGET = {3'b001, 3'b101, 3'b110, 3'b000,
                                3'b110, 3'b110, 3'b011, 3'b101};

    // Reference model
    reg  [23:0] ref_history;
    reg         ref_found;
    wire [23:0] ref_next_history = {ref_history[20:0], data};

    reg  [2:0] pos = 3'd0;
    integer cycle;
    integer detections = 0;
    integer mismatches = 0;
    integer samples = 0;

    sequence_detector dut (
        .clk(clk),
        .reset_n(reset_n),
        .enable(enable),
        .data(data),
        .sequence_found(sequence_found)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            ref_history <= 24'd0;
            ref_found   <= 1'b0;
        end else if (enable) begin
            ref_history <= ref_next_history;
            ref_found   <= (ref_next_history == TARGET);
        end else begin
            ref_found   <= 1'b0;
        end
    end

    function [2:0] target_value;
        input [2:0] k;
        begin
            case (k)
                3'd0: target_value = 3'b001;
                3'd1: target_value = 3'b101;
                3'd2: target_value = 3'b110;
                3'd3: target_value = 3'b000;
                3'd4: target_value = 3'b110;
                3'd5: target_value = 3'b110;
                3'd6: target_value = 3'b011;
                default: target_value = 3'b101;
            endcase
        end
    endfunction

    task check;
        begin
            samples = samples + 1;
            if (sequence_found !== ref_found) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch at time %0t: expected sequence_found=%b got %b (last 8 sampled values, oldest first, in octal: %o)",
                             $time, ref_found, sequence_found, ref_history);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);   // reset held over two rising edges
        reset_n = 1'b1;

        for (cycle = 0; cycle < 3000; cycle = cycle + 1) begin
            @(negedge clk);
            check;
            if (ref_found) detections = detections + 1;

            // Mostly feed the target sequence, mixing in wrong values and disabled cycles
            enable = ({$random} % 10) != 0;
            if (enable) begin
                if (({$random} % 8) != 0) begin
                    data = target_value(pos);
                    pos  = pos + 3'd1;
                end else begin
                    data = $random;
                    pos  = 3'd0;
                end
            end else begin
                data = $random;
            end

            // Occasional asynchronous reset between clock edges
            if (({$random} % 200) == 0) begin
                reset_n = 1'b0;
                pos = 3'd0;
                #1 check;
            end else begin
                reset_n = 1'b1;
            end
        end
        $finish;
    end

    final begin
        $display("Info: the reference model detected the sequence %0d times", detections);
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
