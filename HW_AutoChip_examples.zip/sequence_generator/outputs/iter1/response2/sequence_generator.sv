module sequence_generator (
    input        clk,
    input        reset_n,
    input        enable,
    output reg [7:0] data
);

    reg [2:0] index;
    reg [7:0] sequence [0:7] = {8'hAF, 8'hBC, 8'hE2, 8'h78, 8'hFF, 8'hE2, 8'h0B, 8'h8D};

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            index <= 0;
            data <= 8'hAF; // Reset data to the first value in the sequence
        end else if (enable) begin
            data <= sequence[index]; // Output the current sequence value
            index <= (index + 1) % 8; // Update index for the next value
        end
    end
endmodule
