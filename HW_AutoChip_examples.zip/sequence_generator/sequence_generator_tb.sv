module tb;
    reg        clk = 1'b0;
    reg        reset_n = 1'b0;
    reg        enable = 1'b0;
    wire [7:0] data;

    function [7:0] seq_value;
        input [2:0] k;
        begin
            case (k)
                3'd0: seq_value = 8'hAF;
                3'd1: seq_value = 8'hBC;
                3'd2: seq_value = 8'hE2;
                3'd3: seq_value = 8'h78;
                3'd4: seq_value = 8'hFF;
                3'd5: seq_value = 8'hE2;
                3'd6: seq_value = 8'h0B;
                default: seq_value = 8'h8D;
            endcase
        end
    endfunction

    // Reference model
    reg  [2:0] ref_index;
    wire [7:0] ref_data = seq_value(ref_index);

    integer cycle;
    integer mismatches = 0;
    integer samples = 0;

    sequence_generator dut (
        .clk(clk),
        .reset_n(reset_n),
        .enable(enable),
        .data(data)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n)
            ref_index <= 3'd0;
        else if (enable)
            ref_index <= ref_index + 3'd1;
    end

    task check;
        begin
            samples = samples + 1;
            if (data !== ref_data) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch at time %0t: reset_n=%b enable=%b expected data=8'h%h got 8'h%h",
                             $time, reset_n, enable, ref_data, data);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);   // reset held over two rising edges
        reset_n = 1'b1;
        for (cycle = 0; cycle < 1000; cycle = cycle + 1) begin
            @(negedge clk);
            check;
            enable = ({$random} % 4) != 0;
            if (({$random} % 60) == 0) begin
                reset_n = 1'b0;      // asynchronous reset between clock edges
                #1 check;
            end else begin
                reset_n = 1'b1;
            end
        end
        $finish;
    end

    final begin
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
