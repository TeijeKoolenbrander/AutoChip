// Create a sequence generator.
// Ports:
//   clk     : clock
//   reset_n : active-low ASYNCHRONOUS reset
//   enable  : when 1, the generator advances on the rising edge of clk
//   data    : 8-bit output, the current value of the sequence
//
// The generator outputs these 8 values in order, then repeats forever:
//   8'hAF, 8'hBC, 8'hE2, 8'h78, 8'hFF, 8'hE2, 8'h0B, 8'h8D
// When reset_n is 0, it immediately returns to the first value, 8'hAF.
// On each rising edge of clk where enable is 1, data moves to the next value;
// after 8'h8D it wraps back to 8'hAF. When enable is 0, data holds.
//
// Implementation (follow exactly):
//   - A 3-bit register named index. It resets to 0 when reset_n is 0 and
//     increments by 1 on each rising edge of clk where enable is 1, wrapping
//     from 7 back to 0.
//   - data is combinational from index, using this case statement inside an
//     always @(*) block, so declare the port as output reg [7:0] data:
//       case (index)
//         3'd0: data = 8'hAF;   3'd1: data = 8'hBC;
//         3'd2: data = 8'hE2;   3'd3: data = 8'h78;
//         3'd4: data = 8'hFF;   3'd5: data = 8'hE2;
//         3'd6: data = 8'h0B;   default: data = 8'h8D;
//       endcase
//   - Use no other internal signals.

module sequence_generator (
    input        clk,
    input        reset_n,
    input        enable,
    output [7:0] data
);

endmodule
