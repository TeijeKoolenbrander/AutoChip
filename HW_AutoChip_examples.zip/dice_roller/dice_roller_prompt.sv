// Create a dice roller that produces pseudo-random rolls for a d4, d6, d8, or d20.
// Ports:
//   clk           : clock
//   rst_n         : active-low ASYNCHRONOUS reset
//   die_select    : 2-bit die type: 2'b00 = d4, 2'b01 = d6, 2'b10 = d8, 2'b11 = d20
//   roll          : roll request input
//   rolled_number : 8-bit result of the most recent roll
//
// Random source: a 16-bit LFSR register, called lfsr here, that advances on
// EVERY rising edge of clk:
//   lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
//
// Roll detection: keep a 1-bit register holding the value roll had at the
// previous rising edge. A roll happens on a rising edge of clk where roll is 1
// and was 0 at the previous rising edge.
//
// When a roll happens, set rolled_number to (lfsr % sides) + 1, where sides is
// 4, 6, 8, or 20 according to die_select, and lfsr is the value it held BEFORE
// this clock edge. On edges where no roll happens, rolled_number keeps its value.
//
// When rst_n is 0, immediately set lfsr to 16'hACE1, rolled_number to 8'd1,
// and the previous-roll register to 0.

module dice_roller (
    input        clk,
    input        rst_n,
    input  [1:0] die_select,
    input        roll,
    output [7:0] rolled_number
);

endmodule
