module dice_roller (
    input        clk,
    input        rst_n,
    input  [1:0] die_select,
    input        roll,
    output reg [7:0] rolled_number
);
    reg [15:0] lfsr;
    reg prev_roll;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            lfsr <= 16'hACE1;
            rolled_number <= 8'd1;
            prev_roll <= 1'b0;
        end else begin
            lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
            if (roll && !prev_roll) begin
                case (die_select)
                    2'b00: rolled_number <= (lfsr % 4) + 1;  // d4
                    2'b01: rolled_number <= (lfsr % 6) + 1;  // d6
                    2'b10: rolled_number <= (lfsr % 8) + 1;  // d8
                    2'b11: rolled_number <= (lfsr % 20) + 1; // d20
                    default: rolled_number <= 8'd1;
                endcase
            end
            prev_roll <= roll;
        end
    end
endmodule
