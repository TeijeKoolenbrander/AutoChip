module tb;
    reg        clk = 1'b0;
    reg        rst_n = 1'b0;
    reg  [1:0] die_select = 2'b00;
    reg        roll = 1'b0;
    wire [7:0] rolled_number;

    // Reference model, same algorithm as the specification
    reg [15:0] ref_lfsr;
    reg        ref_roll_prev;
    reg  [7:0] ref_rolled_number;

    reg        next_roll;
    integer cycle;
    integer roll_requests = 0;
    integer mismatches = 0;
    integer samples = 0;

    dice_roller dut (
        .clk(clk),
        .rst_n(rst_n),
        .die_select(die_select),
        .roll(roll),
        .rolled_number(rolled_number)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ref_lfsr          <= 16'hACE1;
            ref_roll_prev     <= 1'b0;
            ref_rolled_number <= 8'd1;
        end else begin
            ref_lfsr      <= {ref_lfsr[14:0], ref_lfsr[15] ^ ref_lfsr[13] ^ ref_lfsr[12] ^ ref_lfsr[10]};
            ref_roll_prev <= roll;
            if (roll && !ref_roll_prev) begin
                case (die_select)
                    2'b00:   ref_rolled_number <= (ref_lfsr % 4)  + 1;
                    2'b01:   ref_rolled_number <= (ref_lfsr % 6)  + 1;
                    2'b10:   ref_rolled_number <= (ref_lfsr % 8)  + 1;
                    default: ref_rolled_number <= (ref_lfsr % 20) + 1;
                endcase
            end
        end
    end

    task check;
        begin
            samples = samples + 1;
            if (rolled_number !== ref_rolled_number) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch at time %0t: rst_n=%b roll=%b die_select=%b expected rolled_number=%0d got %0d",
                             $time, rst_n, roll, die_select, ref_rolled_number, rolled_number);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);   // reset held over two rising edges
        rst_n = 1'b1;
        for (cycle = 0; cycle < 3000; cycle = cycle + 1) begin
            @(negedge clk);
            check;
            next_roll = $random;
            if (next_roll && !roll) roll_requests = roll_requests + 1;
            roll       = next_roll;
            die_select = $random;
            if (({$random} % 500) == 0) begin
                rst_n = 1'b0;        // asynchronous reset between clock edges
                #1 check;
            end else begin
                rst_n = 1'b1;
            end
        end
        $finish;
    end

    final begin
        $display("Info: %0d roll requests were made", roll_requests);
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
