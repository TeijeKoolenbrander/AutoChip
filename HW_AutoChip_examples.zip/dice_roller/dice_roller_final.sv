module dice_roller (
    input        clk,
    input        rst_n,
    input  [1:0] die_select,
    input        roll,
    output reg [7:0] rolled_number
);

    reg [15:0] lfsr;
    reg prev_roll;

    wire [7:0] sides;

    assign sides = (die_select == 2'b00) ? 4 :
                   (die_select == 2'b01) ? 6 :
                   (die_select == 2'b10) ? 8 : 20;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            lfsr <= 16'hACE1;
            rolled_number <= 8'd1;
            prev_roll <= 1'b0;
        end else begin
            lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
            if (roll && !prev_roll) begin
                rolled_number <= (lfsr % sides) + 1;
            end
            prev_roll <= roll;
        end
    end
endmodule
