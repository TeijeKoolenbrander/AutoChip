// Create an 8-bit linear feedback shift register, LFSR.
// Ports:
//   clk     : clock
//   reset_n : active-low ASYNCHRONOUS reset
//   data    : 8-bit LFSR state
//
// When reset_n is 0, data is immediately set to the initial state 8'b10001010.
// On each rising edge of clk while reset_n is 1, data shifts left by one bit and
// the feedback bit enters the least significant bit. The feedback bit is the XOR
// of the taps at bit positions 1, 4, 6, and 7, counting the LSB as position 1,
// which are data[0], data[3], data[5], and data[6]:
//   new data = {old data[6:0], old data[0] ^ old data[3] ^ old data[5] ^ old data[6]}

module lfsr (
    input        clk,
    input        reset_n,
    output [7:0] data
);

endmodule
