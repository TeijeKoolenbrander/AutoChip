module tb;
    reg        clk = 1'b0;
    reg        reset_n = 1'b0;
    wire [7:0] data;

    // Reference model
    reg  [7:0] ref_data;

    integer cycle;
    integer mismatches = 0;
    integer samples = 0;

    lfsr dut (
        .clk(clk),
        .reset_n(reset_n),
        .data(data)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n)
            ref_data <= 8'b10001010;
        else
            ref_data <= {ref_data[6:0], ref_data[0] ^ ref_data[3] ^ ref_data[5] ^ ref_data[6]};
    end

    task check;
        begin
            samples = samples + 1;
            if (data !== ref_data) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch at time %0t: reset_n=%b expected data=%b got %b",
                             $time, reset_n, ref_data, data);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);   // reset held over two rising edges
        reset_n = 1'b1;
        for (cycle = 0; cycle < 600; cycle = cycle + 1) begin
            @(negedge clk);
            check;
            if (({$random} % 150) == 0) begin
                reset_n = 1'b0;      // asynchronous reset between clock edges
                #1 check;
            end else begin
                reset_n = 1'b1;
            end
        end
        $finish;
    end

    final begin
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
