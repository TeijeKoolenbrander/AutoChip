module tb;
    reg  [4:0] binary_input;
    wire [7:0] bcd_output;
    reg  [7:0] expected;
    integer value;
    integer mismatches = 0;
    integer samples = 0;

    binary_to_bcd dut (
        .binary_input(binary_input),
        .bcd_output(bcd_output)
    );

    task apply_and_check;
        input [4:0] v;
        begin
            binary_input = v;
            #10;
            expected[7:4] = v / 10;
            expected[3:0] = v % 10;
            samples = samples + 1;
            if (bcd_output !== expected) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch: binary_input=%0d expected bcd_output=8'h%h got 8'h%h",
                             v, expected, bcd_output);
            end
        end
    endtask

    initial begin
        // Every input value, counting up and then counting down
        for (value = 0; value < 32; value = value + 1)
            apply_and_check(value[4:0]);
        for (value = 31; value >= 0; value = value - 1)
            apply_and_check(value[4:0]);
        $finish;
    end

    final begin
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
