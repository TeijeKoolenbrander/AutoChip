// Create a combinational binary-to-BCD converter.
// binary_input is a 5-bit unsigned binary number with values 0 to 31.
// bcd_output is the same value as two BCD digits:
//   bcd_output[7:4] is the tens digit, 0 to 3
//   bcd_output[3:0] is the ones digit, 0 to 9
// Examples: binary_input = 27 gives bcd_output = 8'h27,
//           binary_input = 9 gives bcd_output = 8'h09.
// The module is purely combinational: no clock and no reset.
//
// If you use the double-dabble (shift-and-add-3) algorithm, then in each of
// the 5 steps: FIRST add 3 to any BCD digit that is 5 or more, THEN shift
// {tens, ones} left by one bit and bring in the next binary bit, MSB first.
// Do not apply the add-3 adjustment after the final shift.

module binary_to_bcd (
    input  [4:0] binary_input,
    output [7:0] bcd_output
);

endmodule
