module binary_to_bcd (
    input  [4:0] binary_input,
    output reg [7:0] bcd_output
);

    always @* begin
        // Clear BCD output
        bcd_output = 8'b0;

        // Binary to BCD conversion process
        for (integer i = 0; i < 5; i = i + 1) begin
            // If the tens digit or ones digit is 5 or more, add 3 to it
            if (bcd_output[7:4] >= 5)
                bcd_output[7:4] = bcd_output[7:4] + 3;
            if (bcd_output[3:0] >= 10)
                bcd_output[3:0] = bcd_output[3:0] + 3;

            // Shift left by 1 to make space for the next binary bit
            bcd_output = {bcd_output[6:0], 1'b0}; // Shift without immediate binary input
            bcd_output[3:0] = bcd_output[3:0] | (binary_input[4-i] ? 1'b1 : 1'b0); // Set the LSB based on binary_input
        end
    end

endmodule
