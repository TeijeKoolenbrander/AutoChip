module binary_to_bcd (
    input  [4:0] binary_input,
    output reg [7:0] bcd_output
);
    integer i;

    always @(*) begin
        // Initialize BCD digits
        reg [3:0] tens = 4'b0000;
        reg [3:0] ones = 4'b0000;
        
        // Process each bit of the binary input
        for (i = 4; i >= 0; i = i - 1) begin
            // Add 3 to any BCD digit that is 5 or more
            if (ones >= 5)
                ones = ones + 4'b0011;
            if (tens >= 5)
                tens = tens + 4'b0011;

            // Shift left and bring in the next binary bit
            {tens, ones} = {tens, ones} << 1;
            ones[0] = binary_input[i];
        end

        // Assign the final BCD output
        bcd_output = {tens, ones};
    end
endmodule
