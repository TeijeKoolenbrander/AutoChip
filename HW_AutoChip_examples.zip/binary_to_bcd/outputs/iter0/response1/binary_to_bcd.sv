module binary_to_bcd (
    input  [4:0] binary_input,
    output reg [7:0] bcd_output
);
    integer i;
    reg [3:0] tens;
    reg [3:0] ones;

    always @* begin
        // Initialize BCD digits
        tens = 4'b0000;
        ones = 4'b0000;

        // Convert binary to BCD using double-dabble algorithm
        for (i = 4; i >= 0; i = i - 1) begin
            // Add 3 to any BCD digit that is 5 or more
            if (ones >= 5)
                ones = ones + 4'd3;
            if (tens >= 5)
                tens = tens + 4'd3;

            // Shift left by one position and bring in the next binary bit
            {tens, ones} = {tens, ones, binary_input[i]};
        end

        // Assign the BCD output
        bcd_output = {tens, ones};
    end
endmodule
