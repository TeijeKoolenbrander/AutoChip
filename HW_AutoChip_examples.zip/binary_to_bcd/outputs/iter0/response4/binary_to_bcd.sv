module binary_to_bcd (
    input  [4:0] binary_input,
    output reg [7:0] bcd_output
);
    integer i;

    always @* begin
        // Initialize BCD output
        bcd_output = 8'b0;

        // Double-dabble algorithm
        for (i = 4; i >= 0; i = i - 1) begin
            // If any BCD digit is 5 or more, add 3
            if (bcd_output[7:4] >= 5) 
                bcd_output[7:4] = bcd_output[7:4] + 3;
            if (bcd_output[3:0] >= 5) 
                bcd_output[3:0] = bcd_output[3:0] + 3;

            // Shift left and bring in the next binary bit
            bcd_output = {bcd_output[6:0], binary_input[i]};
        end

        // No add-3 adjustment after the final shift
    end
endmodule
