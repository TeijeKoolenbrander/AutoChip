module abro_state_machine (
    input        clk,
    input        rst_n,
    input        A,
    input        B,
    output       O,
    output reg [3:0] State
);

    // State encoding
    localparam IDLE   = 4'b0001;
    localparam SEEN_A = 4'b0010;
    localparam SEEN_B = 4'b0100;
    localparam DONE   = 4'b1000;

    // Current state register
    reg [3:0] current_state, next_state;

    // Output logic
    assign O = (current_state == DONE);

    // State transitions
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= IDLE;  // Reset to IDLE
        end else begin
            current_state <= next_state;  // Move to next state
        end
    end

    // Next state logic
    always @(*) begin
        case (current_state)
            IDLE: begin
                if (A && B) begin
                    next_state = DONE;
                end else if (A) begin
                    next_state = SEEN_A;
                end else if (B) begin
                    next_state = SEEN_B;
                end else begin
                    next_state = IDLE;
                end
            end
            
            SEEN_A: begin
                if (B) begin
                    next_state = DONE;
                end else begin
                    next_state = SEEN_A;
                end
            end
            
            SEEN_B: begin
                if (A) begin
                    next_state = DONE;
                end else begin
                    next_state = SEEN_B;
                end
            end
            
            DONE: begin
                next_state = DONE;  // Stay in DONE
            end
            
            default: begin
                next_state = IDLE;  // Fallback to IDLE
            end
        endcase
    end

    // State output
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            State <= IDLE;  // Reset State output
        end else begin
            State <= current_state;  // Update State output
        end
    end

endmodule
