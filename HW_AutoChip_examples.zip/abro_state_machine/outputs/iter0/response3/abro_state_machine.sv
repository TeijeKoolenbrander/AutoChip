module abro_state_machine (
    input        clk,
    input        rst_n,
    input        A,
    input        B,
    output reg   O,
    output reg [3:0] State
);

    // State encoding
    localparam IDLE   = 4'b0001;
    localparam SEEN_A = 4'b0010;
    localparam SEEN_B = 4'b0100;
    localparam DONE   = 4'b1000;

    // Current state register
    reg [3:0] current_state;

    // State transition
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= IDLE;
        end else begin
            case (current_state)
                IDLE: begin
                    if (A && B) 
                        current_state <= DONE;
                    else if (A) 
                        current_state <= SEEN_A;
                    else if (B) 
                        current_state <= SEEN_B;
                    // else stay in IDLE
                end
                SEEN_A: begin
                    if (B) 
                        current_state <= DONE;
                    // else stay in SEEN_A
                end
                SEEN_B: begin
                    if (A) 
                        current_state <= DONE;
                    // else stay in SEEN_B
                end
                DONE: begin
                    // stay in DONE until reset
                end
            endcase
        end
    end

    // Output logic
    always @(*) begin
        O = (current_state == DONE);
        State = current_state;
    end
endmodule
