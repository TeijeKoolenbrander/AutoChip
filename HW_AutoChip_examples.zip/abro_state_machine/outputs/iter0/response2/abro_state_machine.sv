module abro_state_machine (
    input        clk,
    input        rst_n,
    input        A,
    input        B,
    output       O,
    output [3:0] State
);

    reg [3:0] current_state, next_state;

    // State Definitions
    localparam IDLE   = 4'b0001;
    localparam SEEN_A = 4'b0010;
    localparam SEEN_B = 4'b0100;
    localparam DONE   = 4'b1000;

    // State Register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            current_state <= IDLE;
        else
            current_state <= next_state;
    end

    // Next State Logic
    always @(*) begin
        case (current_state)
            IDLE: begin
                if (A && B)
                    next_state = DONE;
                else if (A)
                    next_state = SEEN_A;
                else if (B)
                    next_state = SEEN_B;
                else
                    next_state = IDLE;
            end
            
            SEEN_A: begin
                if (B)
                    next_state = DONE;
                else
                    next_state = SEEN_A;
            end
            
            SEEN_B: begin
                if (A)
                    next_state = DONE;
                else
                    next_state = SEEN_B;
            end
            
            DONE: begin
                next_state = DONE;
            end
            
            default: next_state = IDLE;
        endcase
    end

    // Output Logic
    assign O = (current_state == DONE) ? 1'b1 : 1'b0;
    assign State = current_state;

endmodule
