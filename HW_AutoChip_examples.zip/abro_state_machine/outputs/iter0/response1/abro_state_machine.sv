module abro_state_machine (
    input        clk,
    input        rst_n,
    input        A,
    input        B,
    output reg   O,
    output reg [3:0] State
);

    // State encoding
    parameter IDLE   = 4'b0001;
    parameter SEEN_A = 4'b0010;
    parameter SEEN_B = 4'b0100;
    parameter DONE   = 4'b1000;

    // Current state and next state registers
    reg [3:0] current_state, next_state;

    // State transition
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_state <= IDLE;
        end else begin
            current_state <= next_state;
        end
    end

    // Next state logic
    always @(*) begin
        case (current_state)
            IDLE: begin
                if (A && B) next_state = DONE;
                else if (A) next_state = SEEN_A;
                else if (B) next_state = SEEN_B;
                else next_state = IDLE;
            end
            SEEN_A: begin
                if (B) next_state = DONE;
                else next_state = SEEN_A;
            end
            SEEN_B: begin
                if (A) next_state = DONE;
                else next_state = SEEN_B;
            end
            DONE: begin
                next_state = DONE;
            end
            default: next_state = IDLE; // safety default
        endcase
    end

    // Output logic
    always @(*) begin
        O = (current_state == DONE);
    end

    // Assign output State
    always @(*) begin
        State = current_state;
    end

endmodule
