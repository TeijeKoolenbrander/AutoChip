// Create an ABRO state machine: wait until both A and B have been seen,
// in either order, then assert O until the machine is reset.
// Ports:
//   clk   : clock
//   rst_n : active-low ASYNCHRONOUS reset; this is the R of ABRO
//   A, B  : inputs, sampled on the rising edge of clk
//   O     : output
//   State : 4-bit one-hot current state, provided for verification
//
// States and their one-hot encodings:
//   IDLE   = 4'b0001 : neither A nor B has been seen yet
//   SEEN_A = 4'b0010 : A has been seen, waiting for B
//   SEEN_B = 4'b0100 : B has been seen, waiting for A
//   DONE   = 4'b1000 : both A and B have been seen
//
// When rst_n is 0, the machine goes to IDLE immediately.
// On each rising edge of clk while rst_n is 1:
//   IDLE:   if A and B are both 1, go to DONE;
//           else if A is 1, go to SEEN_A;
//           else if B is 1, go to SEEN_B;
//           else stay in IDLE.
//   SEEN_A: if B is 1, go to DONE, otherwise stay in SEEN_A.
//   SEEN_B: if A is 1, go to DONE, otherwise stay in SEEN_B.
//   DONE:   stay in DONE until reset.
// State always shows the current state register.
// O is 1 exactly when the current state is DONE.

module abro_state_machine (
    input        clk,
    input        rst_n,
    input        A,
    input        B,
    output       O,
    output [3:0] State
);

endmodule
