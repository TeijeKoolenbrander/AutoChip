module abro_state_machine (
    input        clk,
    input        rst_n,
    input        A,
    input        B,
    output reg   O,
    output reg [3:0] State
);

// State encoding
parameter IDLE   = 4'b0001;
parameter SEEN_A = 4'b0010;
parameter SEEN_B = 4'b0100;
parameter DONE   = 4'b1000;

// State register
reg [3:0] current_state, next_state;

// Sequential logic for state transition
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        current_state <= IDLE;
    else
        current_state <= next_state;
end

// Combinational logic for next state and output
always @(*) begin
    // Default values
    next_state = current_state;
    O = 0;

    case (current_state)
        IDLE: begin
            if (A && B)
                next_state = DONE;
            else if (A)
                next_state = SEEN_A;
            else if (B)
                next_state = SEEN_B;
        end
        SEEN_A: begin
            if (B)
                next_state = DONE;
        end
        SEEN_B: begin
            if (A)
                next_state = DONE;
        end
        DONE: begin
            O = 1; // Assert output until reset
        end
    endcase
end

// Current state output
always @(*) begin
    State = current_state; // Update State output
end

endmodule
