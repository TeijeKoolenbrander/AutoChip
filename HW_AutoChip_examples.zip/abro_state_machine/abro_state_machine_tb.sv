module tb;
    reg        clk = 1'b0;
    reg        rst_n = 1'b0;
    reg        A = 1'b0;
    reg        B = 1'b0;
    wire       O;
    wire [3:0] State;

    localparam [3:0] IDLE   = 4'b0001;
    localparam [3:0] SEEN_A = 4'b0010;
    localparam [3:0] SEEN_B = 4'b0100;
    localparam [3:0] DONE   = 4'b1000;

    // Reference model
    reg  [3:0] ref_state;
    wire       ref_O = (ref_state == DONE);

    integer cycle;
    integer done_cycles = 0;
    integer mismatches = 0;
    integer samples = 0;

    abro_state_machine dut (
        .clk(clk),
        .rst_n(rst_n),
        .A(A),
        .B(B),
        .O(O),
        .State(State)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            ref_state <= IDLE;
        else begin
            case (ref_state)
                IDLE: begin
                    if (A && B)
                        ref_state <= DONE;
                    else if (A)
                        ref_state <= SEEN_A;
                    else if (B)
                        ref_state <= SEEN_B;
                end
                SEEN_A: if (B) ref_state <= DONE;
                SEEN_B: if (A) ref_state <= DONE;
                default: ref_state <= DONE;
            endcase
        end
    end

    task check;
        begin
            samples = samples + 1;
            if ((State !== ref_state) || (O !== ref_O)) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch at time %0t: rst_n=%b A=%b B=%b expected State=%b O=%b got State=%b O=%b",
                             $time, rst_n, A, B, ref_state, ref_O, State, O);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);   // reset held over two rising edges
        rst_n = 1'b1;
        for (cycle = 0; cycle < 2000; cycle = cycle + 1) begin
            @(negedge clk);
            check;
            if (ref_O) done_cycles = done_cycles + 1;
            A = ({$random} % 4) == 0;
            B = ({$random} % 4) == 0;
            if (({$random} % 8) == 0) begin
                rst_n = 1'b0;        // asynchronous reset between clock edges
                #1 check;
            end else begin
                rst_n = 1'b1;
            end
        end
        $finish;
    end

    final begin
        $display("Info: the reference model was in DONE for %0d checked cycles", done_cycles);
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
