module tb;
    reg        clk = 1'b0;
    reg        reset_n = 1'b0;
    reg        data_in = 1'b0;
    reg        shift_enable = 1'b0;
    wire [7:0] data_out;

    // Reference model
    reg  [7:0] ref_data_out;

    integer cycle;
    integer mismatches = 0;
    integer samples = 0;

    shift_register dut (
        .clk(clk),
        .reset_n(reset_n),
        .data_in(data_in),
        .shift_enable(shift_enable),
        .data_out(data_out)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n)
            ref_data_out <= 8'd0;
        else if (shift_enable)
            ref_data_out <= {ref_data_out[6:0], data_in};
    end

    task check;
        begin
            samples = samples + 1;
            if (data_out !== ref_data_out) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch at time %0t: reset_n=%b shift_enable=%b data_in=%b expected data_out=%b got %b",
                             $time, reset_n, shift_enable, data_in, ref_data_out, data_out);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);   // reset held over two rising edges
        reset_n = 1'b1;
        for (cycle = 0; cycle < 1000; cycle = cycle + 1) begin
            @(negedge clk);
            check;
            data_in      = $random;
            shift_enable = ({$random} % 4) != 0;
            if (({$random} % 50) == 0) begin
                reset_n = 1'b0;      // asynchronous reset between clock edges
                #1 check;
            end else begin
                reset_n = 1'b1;
            end
        end
        $finish;
    end

    final begin
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
