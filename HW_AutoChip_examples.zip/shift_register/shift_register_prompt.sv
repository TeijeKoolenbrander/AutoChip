// Create an 8-bit shift register.
// Ports:
//   clk          : clock
//   reset_n      : active-low ASYNCHRONOUS reset; when 0, data_out is cleared to 0 immediately
//   data_in      : 1-bit serial input
//   shift_enable : when 1, the register shifts on the rising edge of clk
//   data_out     : 8-bit register contents
//
// On each rising edge of clk where shift_enable is 1, the register shifts left
// by one bit and data_in enters the least significant bit:
//   new data_out = {old data_out[6:0], data_in}
// When shift_enable is 0, data_out holds its value.

module shift_register (
    input        clk,
    input        reset_n,
    input        data_in,
    input        shift_enable,
    output [7:0] data_out
);

endmodule
