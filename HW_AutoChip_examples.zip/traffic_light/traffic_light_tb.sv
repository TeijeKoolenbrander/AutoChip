module tb;
    reg  clk = 1'b0;
    reg  reset_n = 1'b0;
    reg  enable = 1'b0;
    wire red;
    wire yellow;
    wire green;

    localparam [1:0] RED    = 2'd0;
    localparam [1:0] GREEN  = 2'd1;
    localparam [1:0] YELLOW = 2'd2;

    // Reference model
    reg  [1:0] ref_color;
    reg  [5:0] ref_count;
    wire       ref_red    = (ref_color == RED);
    wire       ref_green  = (ref_color == GREEN);
    wire       ref_yellow = (ref_color == YELLOW);

    integer cycle;
    integer mismatches = 0;
    integer samples = 0;

    traffic_light dut (
        .clk(clk),
        .reset_n(reset_n),
        .enable(enable),
        .red(red),
        .yellow(yellow),
        .green(green)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            ref_color <= RED;
            ref_count <= 6'd0;
        end else if (enable) begin
            case (ref_color)
                RED:
                    if (ref_count == 6'd31) begin
                        ref_color <= GREEN;
                        ref_count <= 6'd0;
                    end else
                        ref_count <= ref_count + 6'd1;
                GREEN:
                    if (ref_count == 6'd19) begin
                        ref_color <= YELLOW;
                        ref_count <= 6'd0;
                    end else
                        ref_count <= ref_count + 6'd1;
                default:
                    if (ref_count == 6'd6) begin
                        ref_color <= RED;
                        ref_count <= 6'd0;
                    end else
                        ref_count <= ref_count + 6'd1;
            endcase
        end
    end

    task check;
        begin
            samples = samples + 1;
            if ({red, yellow, green} !== {ref_red, ref_yellow, ref_green}) begin
                mismatches = mismatches + 1;
                if (mismatches <= 10)
                    $display("Mismatch at time %0t: reset_n=%b enable=%b expected red,yellow,green=%b%b%b got %b%b%b",
                             $time, reset_n, enable, ref_red, ref_yellow, ref_green, red, yellow, green);
            end
        end
    endtask

    initial begin
        repeat (2) @(negedge clk);   // reset held over two rising edges
        reset_n = 1'b1;
        for (cycle = 0; cycle < 3000; cycle = cycle + 1) begin
            @(negedge clk);
            check;
            enable = ({$random} % 20) >= 3;
            if (({$random} % 700) == 0) begin
                reset_n = 1'b0;      // asynchronous reset between clock edges
                #1 check;
            end else begin
                reset_n = 1'b1;
            end
        end
        $finish;
    end

    final begin
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
