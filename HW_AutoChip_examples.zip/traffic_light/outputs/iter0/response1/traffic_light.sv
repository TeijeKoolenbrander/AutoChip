module traffic_light (
    input  clk,
    input  reset_n,
    input  enable,
    output reg red,
    output reg yellow,
    output reg green
);

    reg [5:0] count; // To count the enabled clock edges
    reg [1:0] state; // To hold the current state
    parameter RED    = 2'b00;
    parameter GREEN  = 2'b01;
    parameter YELLOW = 2'b10;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            red <= 1'b1;
            yellow <= 1'b0;
            green <= 1'b0;
            count <= 6'b0;
            state <= RED;
        end else if (enable) begin
            count <= count + 1;
            case (state)
                RED: begin
                    if (count >= 32) begin
                        red <= 1'b0;
                        green <= 1'b1;
                        yellow <= 1'b0;
                        state <= GREEN;
                        count <= 6'b0;
                    end
                end
                GREEN: begin
                    if (count >= 20) begin
                        green <= 1'b0;
                        yellow <= 1'b1;
                        red <= 1'b0;
                        state <= YELLOW;
                        count <= 6'b0;
                    end
                end
                YELLOW: begin
                    if (count >= 7) begin
                        yellow <= 1'b0;
                        red <= 1'b1;
                        green <= 1'b0;
                        state <= RED;
                        count <= 6'b0;
                    end
                end
            endcase
        end
    end

endmodule
