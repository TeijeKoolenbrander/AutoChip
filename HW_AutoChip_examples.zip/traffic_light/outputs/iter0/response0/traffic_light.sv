module traffic_light (
    input  clk,
    input  reset_n,
    input  enable,
    output reg red,
    output reg yellow,
    output reg green
);

    reg [5:0] count; // 6 bits to count up to 63 (32 + 20 + 7)
    reg [1:0] state; // 2 bits for the states: 00 = RED, 01 = GREEN, 10 = YELLOW
    parameter RED = 2'b00, GREEN = 2'b01, YELLOW = 2'b10;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            // Asynchronous reset
            red <= 1;
            yellow <= 0;
            green <= 0;
            count <= 0;
            state <= RED;
        end else if (enable) begin
            count <= count + 1;
            case (state)
                RED: begin
                    if (count == 31) begin // 32nd enabled edge
                        red <= 0;
                        green <= 1;
                        yellow <= 0;
                        count <= 0;
                        state <= GREEN;
                    end
                end
                GREEN: begin
                    if (count == 19) begin // 20th enabled edge
                        green <= 0;
                        yellow <= 1;
                        red <= 0;
                        count <= 0;
                        state <= YELLOW;
                    end
                end
                YELLOW: begin
                    if (count == 6) begin // 7th enabled edge
                        yellow <= 0;
                        red <= 1;
                        green <= 0;
                        count <= 0;
                        state <= RED;
                    end
                end
            endcase
        end
    end

endmodule
