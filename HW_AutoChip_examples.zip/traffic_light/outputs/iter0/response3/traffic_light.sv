module traffic_light (
    input  clk,
    input  reset_n,
    input  enable,
    output reg red,
    output reg yellow,
    output reg green
);

    reg [5:0] state; // State variable to keep track of current state 
    reg [5:0] count; // Counter for counting enabled rising edges

    // Enum for states
    localparam RED    = 2'b00;
    localparam GREEN  = 2'b01;
    localparam YELLOW = 2'b10;

    // State transition process
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            // Reset condition
            red <= 1'b1;
            yellow <= 1'b0;
            green <= 1'b0;
            count <= 6'b0;
            state <= RED;
        end else if (enable) begin
            // Count enabled rising edges
            count <= count + 1;

            case (state)
                RED: begin
                    if (count == 32) begin
                        // Change from RED to GREEN
                        red <= 1'b0;
                        green <= 1'b1;
                        yellow <= 1'b0;
                        state <= GREEN;
                        count <= 6'b0;
                    end
                end
                GREEN: begin
                    if (count == 20) begin
                        // Change from GREEN to YELLOW
                        green <= 1'b0;
                        yellow <= 1'b1;
                        red <= 1'b0;
                        state <= YELLOW;
                        count <= 6'b0;
                    end
                end
                YELLOW: begin
                    if (count == 7) begin
                        // Change from YELLOW to RED
                        yellow <= 1'b0;
                        red <= 1'b1;
                        green <= 1'b0;
                        state <= RED;
                        count <= 6'b0;
                    end
                end
            endcase
        end
    end

endmodule
