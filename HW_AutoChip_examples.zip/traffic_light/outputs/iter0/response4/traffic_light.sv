module traffic_light (
    input         clk,
    input         reset_n,
    input         enable,
    output reg    red,
    output reg    yellow,
    output reg    green
);

    reg [5:0] count; // Counter to count enabled clock edges
    typedef enum reg [1:0] {RED, GREEN, YELLOW} state_t; // State encoding
    state_t current_state, next_state;

    // State transition logic
    always @(*) begin
        case (current_state)
            RED:    next_state = (count >= 32) ? GREEN : RED;
            GREEN:  next_state = (count >= 20) ? YELLOW : GREEN;
            YELLOW: next_state = (count >= 7) ? RED : YELLOW;
            default: next_state = RED; // Default to RED for safety
        endcase
    end

    // Output logic
    always @(*) begin
        red = (current_state == RED);
        yellow = (current_state == YELLOW);
        green = (current_state == GREEN);
    end

    // Sequential logic for reset and counting
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            current_state <= RED;
            count <= 6'b0;
        end else if (enable) begin
            if (current_state == next_state) begin
                count <= count + 1;
            end else begin
                count <= 6'b0; // Reset count on state change
            end
            current_state <= next_state;
        end
    end

endmodule
