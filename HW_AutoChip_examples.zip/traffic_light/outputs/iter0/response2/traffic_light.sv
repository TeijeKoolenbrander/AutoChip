module traffic_light (
    input  clk,
    input  reset_n,
    input  enable,
    output reg red,
    output reg yellow,
    output reg green
);

    reg [4:0] state; // State to hold the current light state
    reg [4:0] count; // Counter for timing

    localparam RED = 5'b00001;
    localparam GREEN = 5'b00010;
    localparam YELLOW = 5'b00100;

    // Timing parameters
    localparam RED_TIME = 32;
    localparam GREEN_TIME = 20;
    localparam YELLOW_TIME = 7;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            red <= 1;
            yellow <= 0;
            green <= 0;
            state <= RED;
            count <= 0;
        end else if (enable) begin
            count <= count + 1;

            case (state)
                RED: begin
                    red <= 1;
                    yellow <= 0;
                    green <= 0;
                    if (count >= RED_TIME) begin
                        state <= GREEN;
                        count <= 0;
                    end
                end
                GREEN: begin
                    red <= 0;
                    yellow <= 0;
                    green <= 1;
                    if (count >= GREEN_TIME) begin
                        state <= YELLOW;
                        count <= 0;
                    end
                end
                YELLOW: begin
                    red <= 0;
                    yellow <= 1;
                    green <= 0;
                    if (count >= YELLOW_TIME) begin
                        state <= RED;
                        count <= 0;
                    end
                end
            endcase
        end
    end

endmodule
