// Create a traffic light controller.
// Ports:
//   clk     : clock
//   reset_n : active-low ASYNCHRONOUS reset
//   enable  : rising edges of clk only count when enable is 1
//   red, yellow, green : light outputs; exactly one of them is 1 at any time
//
// The light cycles RED -> GREEN -> YELLOW -> RED -> ... forever.
// When reset_n is 0, the light immediately becomes RED and its timing restarts.
// The light stays in each color for a fixed number of enabled rising clock
// edges, then changes color:
//   RED changes to GREEN on the 32nd enabled edge after it became RED.
//   GREEN changes to YELLOW on the 20th enabled edge after it became GREEN.
//   YELLOW changes to RED on the 7th enabled edge after it became YELLOW.
// Rising edges where enable is 0 are ignored: the color and the timing hold.

module traffic_light (
    input  clk,
    input  reset_n,
    input  enable,
    output red,
    output yellow,
    output green
);

endmodule
