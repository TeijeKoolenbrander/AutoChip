module tb;
    reg        clk = 1'b0;
    reg        rst_n = 1'b0;
    wire [7:0] acc_out;
    wire [3:0] pc_out;
    wire       carry_out;
    wire       halted;

    // Program to load for the current test
    reg  [7:0] prog [0:15];

    // Reference model: instruction-level, single-cycle
    reg  [7:0] ref_mem [0:15];
    reg  [3:0] ref_pc;
    reg  [7:0] ref_acc;
    reg        ref_c;
    reg        ref_halted;
    reg  [7:0] ref_last_instr;
    wire [7:0] ref_instr = ref_mem[ref_pc];
    wire [3:0] ref_op    = ref_instr[7:4];
    wire [3:0] ref_arg   = ref_instr[3:0];
    wire [7:0] ref_mval  = ref_mem[ref_arg];

    integer test_num = 0;
    integer p, q;
    integer mismatches = 0;
    integer samples = 0;

    cpu dut (
        .clk(clk),
        .rst_n(rst_n),
        .acc_out(acc_out),
        .pc_out(pc_out),
        .carry_out(carry_out),
        .halted(halted)
    );

    always #5 clk = ~clk;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ref_pc         <= 4'd0;
            ref_acc        <= 8'd0;
            ref_c          <= 1'b0;
            ref_halted     <= 1'b0;
            ref_last_instr <= 8'h00;
        end else if (!ref_halted) begin
            ref_last_instr <= ref_instr;
            case (ref_op)
                4'h0: begin ref_acc <= ref_mval;            ref_pc <= ref_pc + 4'd1; end
                4'h1: begin ref_mem[ref_arg] <= ref_acc;    ref_pc <= ref_pc + 4'd1; end
                4'h2: begin {ref_c, ref_acc} <= {1'b0, ref_acc} + {1'b0, ref_mval};
                            ref_pc <= ref_pc + 4'd1; end
                4'h3: begin ref_acc <= ref_acc - ref_mval;
                            ref_c   <= (ref_acc < ref_mval);
                            ref_pc  <= ref_pc + 4'd1; end
                4'h4: begin ref_acc <= ref_acc & ref_mval;  ref_pc <= ref_pc + 4'd1; end
                4'h5: begin ref_acc <= ref_acc | ref_mval;  ref_pc <= ref_pc + 4'd1; end
                4'h6: begin ref_acc <= ref_acc ^ ref_mval;  ref_pc <= ref_pc + 4'd1; end
                4'h7: ref_pc <= ref_arg;
                4'h8: ref_pc <= (ref_acc == 8'd0) ? ref_arg : ref_pc + 4'd1;
                4'h9: ref_pc <= ref_c ? ref_arg : ref_pc + 4'd1;
                4'hA: begin ref_acc <= {4'b0000, ref_arg};  ref_pc <= ref_pc + 4'd1; end
                4'hB: begin ref_acc <= {ref_acc[6:0], 1'b0}; ref_c <= ref_acc[7];
                            ref_pc  <= ref_pc + 4'd1; end
                4'hC: begin ref_acc <= {1'b0, ref_acc[7:1]}; ref_c <= ref_acc[0];
                            ref_pc  <= ref_pc + 4'd1; end
                4'hD: ref_halted <= 1'b1;
                default: ref_pc <= ref_pc + 4'd1;   // 1110 and 1111 are NOP
            endcase
        end
    end

    function [39:0] mnemonic;
        input [3:0] op;
        begin
            case (op)
                4'h0: mnemonic = "LOAD ";
                4'h1: mnemonic = "STORE";
                4'h2: mnemonic = "ADD  ";
                4'h3: mnemonic = "SUB  ";
                4'h4: mnemonic = "AND  ";
                4'h5: mnemonic = "OR   ";
                4'h6: mnemonic = "XOR  ";
                4'h7: mnemonic = "JMP  ";
                4'h8: mnemonic = "JZ   ";
                4'h9: mnemonic = "JC   ";
                4'hA: mnemonic = "LDI  ";
                4'hB: mnemonic = "SHL  ";
                4'hC: mnemonic = "SHR  ";
                4'hD: mnemonic = "HALT ";
                default: mnemonic = "NOP  ";
            endcase
        end
    endfunction

    task clear_program;
        integer k;
        begin
            for (k = 0; k < 16; k = k + 1)
                prog[k] = 8'h00;
        end
    endtask

    task run_test;
        input integer cycles;
        integer c, k;
        begin
            // Reset, then load the same program into the CPU and the reference model
            @(negedge clk);
            rst_n = 1'b0;
            for (k = 0; k < 16; k = k + 1) begin
                dut.mem[k] = prog[k];
                ref_mem[k] = prog[k];
            end
            repeat (2) @(negedge clk);
            rst_n = 1'b1;

            // Compare the architectural state after every clock edge
            for (c = 1; c <= cycles; c = c + 1) begin
                @(negedge clk);
                samples = samples + 1;
                if ({acc_out, pc_out, carry_out, halted} !== {ref_acc, ref_pc, ref_c, ref_halted}) begin
                    mismatches = mismatches + 1;
                    if (mismatches <= 10)
                        $display("Mismatch in test %0d, cycle %0d, after executing 8'h%h (%s): expected acc=8'h%h pc=%0d carry=%b halted=%b, got acc=8'h%h pc=%0d carry=%b halted=%b",
                                 test_num, c, ref_last_instr, mnemonic(ref_last_instr[7:4]),
                                 ref_acc, ref_pc, ref_c, ref_halted,
                                 acc_out, pc_out, carry_out, halted);
                end
            end

            // Compare the final memory contents
            for (k = 0; k < 16; k = k + 1) begin
                samples = samples + 1;
                if (dut.mem[k] !== ref_mem[k]) begin
                    mismatches = mismatches + 1;
                    if (mismatches <= 10)
                        $display("Mismatch in test %0d: after %0d cycles expected mem[%0d]=8'h%h, got 8'h%h",
                                 test_num, cycles, k, ref_mem[k], dut.mem[k]);
                end
            end
            test_num = test_num + 1;
        end
    endtask

    initial begin
        // Test 0: the test program from the ChipChat design
        clear_program;
        prog[0]  = 8'hA5;  // LDI 5
        prog[1]  = 8'h1C;  // STORE 12
        prog[2]  = 8'hA3;  // LDI 3
        prog[3]  = 8'h2C;  // ADD 12
        prog[4]  = 8'h1D;  // STORE 13
        prog[5]  = 8'h3D;  // SUB 13
        prog[6]  = 8'h89;  // JZ 9
        prog[7]  = 8'hAF;  // LDI 15     (skipped)
        prog[8]  = 8'hD0;  // HALT       (skipped)
        prog[9]  = 8'hA7;  // LDI 7
        prog[10] = 8'h1E;  // STORE 14
        prog[11] = 8'hD0;  // HALT
        run_test(30);

        // Test 1: carry and borrow, shifts, JC taken and not taken
        clear_program;
        prog[0]  = 8'h0E;  // LOAD 14    ACC = F0
        prog[1]  = 8'h2F;  // ADD 15     ACC = 10, C = 1
        prog[2]  = 8'h94;  // JC 4       taken
        prog[3]  = 8'hD0;  // HALT       (skipped)
        prog[4]  = 8'hC0;  // SHR        ACC = 08, C = 0
        prog[5]  = 8'h93;  // JC 3       not taken
        prog[6]  = 8'hB0;  // SHL        ACC = 10, C = 0
        prog[7]  = 8'h1D;  // STORE 13   mem[13] = 10
        prog[8]  = 8'h3E;  // SUB 14     ACC = 20, C = 1 (borrow)
        prog[9]  = 8'h9B;  // JC 11      taken
        prog[10] = 8'hD0;  // HALT       (skipped)
        prog[11] = 8'h6F;  // XOR 15     ACC = 00
        prog[12] = 8'hD0;  // HALT
        prog[14] = 8'hF0;
        prog[15] = 8'h20;
        run_test(30);

        // Test 2: LDI, OR, AND, both NOP encodings, JMP, SHL carry out
        clear_program;
        prog[0]  = 8'hAC;  // LDI 12     ACC = 0C
        prog[1]  = 8'h5F;  // OR 15      ACC = 5D
        prog[2]  = 8'h4E;  // AND 14     ACC = 1C
        prog[3]  = 8'hE0;  // NOP
        prog[4]  = 8'hF7;  // 1111 = NOP
        prog[5]  = 8'h78;  // JMP 8
        prog[6]  = 8'hA1;  // LDI 1      (skipped)
        prog[7]  = 8'hD0;  // HALT       (skipped)
        prog[8]  = 8'h1F;  // STORE 15   mem[15] = 1C
        prog[9]  = 8'hB0;  // SHL        ACC = 38
        prog[10] = 8'hB0;  // SHL        ACC = 70
        prog[11] = 8'hB0;  // SHL        ACC = E0
        prog[12] = 8'hB0;  // SHL        ACC = C0, C = 1
        prog[13] = 8'hD0;  // HALT
        prog[14] = 8'h3C;
        prog[15] = 8'h51;
        run_test(30);

        // Tests 3-32: random programs, compared against the reference model
        for (p = 0; p < 30; p = p + 1) begin
            for (q = 0; q < 16; q = q + 1)
                prog[q] = $random;
            run_test(60);
        end
        $finish;
    end

    final begin
        $display("Info: ran %0d test programs", test_num);
        $display("Mismatches: %0d in %0d samples", mismatches, samples);
    end
endmodule
