module cpu (
    input        clk,
    input        rst_n,
    output [7:0] acc_out,
    output [3:0] pc_out,
    output       carry_out,
    output       halted
);
    reg [7:0] ACC;               // 8-bit accumulator
    reg [3:0] PC;                // 4-bit program counter
    reg C;                       // 1-bit carry flag
    reg halted_flag;             // 1-bit halted flag
    reg [7:0] mem [0:15];       // Unified program/data memory

    assign acc_out = ACC;
    assign pc_out = PC;
    assign carry_out = C;
    assign halted = halted_flag;

    wire [7:0] instr = mem[PC]; // Instruction fetch
    wire [3:0] operand = instr[3:0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            PC <= 0;
            ACC <= 0;
            C <= 0;
            halted_flag <= 0;
        end else if (!halted_flag) begin
            case (instr[7:4])
                4'b0000: ACC <= mem[operand]; // LOAD
                4'b0001: mem[operand] <= ACC;  // STORE
                4'b0010: {C, ACC} <= {1'b0, ACC} + {1'b0, mem[operand]}; // ADD
                4'b0011: begin // SUB
                    {C, ACC} <= {1'b0, ACC} - {1'b0, mem[operand]};
                    C <= (ACC < mem[operand]) ? 1 : 0;
                end
                4'b0100: ACC <= ACC & mem[operand]; // AND
                4'b0101: ACC <= ACC | mem[operand]; // OR
                4'b0110: ACC <= ACC ^ mem[operand]; // XOR
                4'b0111: PC <= operand;              // JMP
                4'b1000: PC <= (ACC == 0) ? operand : PC + 1; // JZ
                4'b1001: PC <= (C == 1) ? operand : PC + 1;    // JC
                4'b1010: ACC <= {4'b0000, operand}; // LDI
                4'b1011: begin // SHL
                    C <= ACC[7];
                    ACC <= ACC << 1;
                end
                4'b1100: begin // SHR
                    C <= ACC[0];
                    ACC <= ACC >> 1;
                end
                4'b1101: halted_flag <= 1;         // HALT
                4'b1110: ;                         // NOP
                4'b1111: ;                         // NOP
            endcase

            // Increment PC for all instructions except JMP, JZ, JC, HALT
            if (instr[7:4] != 4'b0111 && instr[7:4] != 4'b1000 && instr[7:4] != 4'b1001 && instr[7:4] != 4'b1101) begin
                PC <= (PC + 1) & 4'hF; // Wrap around
            end
        end
    end
endmodule
