module cpu (
    input        clk,
    input        rst_n,
    output [7:0] acc_out,
    output [3:0] pc_out,
    output       carry_out,
    output       halted
);

    reg [7:0] ACC;               // 8-bit accumulator
    reg [3:0] PC;                // 4-bit program counter
    reg C;                       // 1-bit carry flag
    reg halted;                  // 1-bit halted flag
    reg [7:0] mem [0:15];       // Memory declaration

    // Continuous assignments for instruction and operand
    wire [7:0] instr = mem[PC];
    wire [7:0] operand = mem[instr[3:0]];

    // Update outputs
    assign acc_out = ACC;
    assign pc_out = PC;
    assign carry_out = C;
    assign halted = halted;

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n) begin
            PC <= 4'b0000;       // Reset PC
            ACC <= 8'b00000000;  // Reset ACC
            C <= 1'b0;           // Reset carry flag
            halted <= 1'b0;      // Reset halted flag
        end else if (!halted) begin
            case (instr[7:4])
                4'b0000: ACC <= operand;                           // LOAD
                4'b0001: mem[instr[3:0]] <= ACC;                   // STORE
                4'b0010: {C, ACC} <= ACC + operand;                // ADD
                4'b0011: begin                                      // SUB
                    {C, ACC} <= ACC - operand;
                end
                4'b0100: ACC <= ACC & operand;                      // AND
                4'b0101: ACC <= ACC | operand;                      // OR
                4'b0110: ACC <= ACC ^ operand;                      // XOR
                4'b0111: PC <= instr[3:0];                          // JMP
                4'b1000: PC <= (ACC == 8'b00000000) ? instr[3:0] : PC + 1; // JZ
                4'b1001: PC <= (C == 1'b1) ? instr[3:0] : PC + 1; // JC
                4'b1010: ACC <= {4'b0000, instr[3:0]};             // LDI
                4'b1011: begin                                      // SHL
                    C <= ACC[7];
                    ACC <= ACC << 1;
                end
                4'b1100: begin                                      // SHR
                    C <= ACC[0];
                    ACC <= ACC >> 1;
                end
                4'b1101: halted <= 1'b1;                            // HALT
                4'b1110: PC <= PC + 1;                             // NOP
                4'b1111: PC <= PC + 1;                             // NOP
            endcase

            if (instr[7:4] != 4'b0111 && instr[7:4] != 4'b1000 && 
                instr[7:4] != 4'b1001 && instr[7:4] != 4'b1101) 
            begin
                PC <= PC + 1;                                     // Increment PC
                if (PC == 4'b1111) PC <= 4'b0000;                // Wraparound
            end
        end
    end

endmodule
