module cpu (
    input        clk,
    input        rst_n,
    output [7:0] acc_out,
    output [3:0] pc_out,
    output       carry_out,
    output       halted
);

    reg [7:0] ACC;
    reg [3:0] PC;
    reg C;
    reg halted_flag;
    reg [7:0] mem [0:15];
    
    wire [7:0] instr;
    wire [3:0] operand;

    assign instr = mem[PC];
    assign operand = instr[3:0];
    assign acc_out = ACC;
    assign pc_out = PC;
    assign carry_out = C;
    assign halted = halted_flag;

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n) begin
            PC <= 4'b0000;
            ACC <= 8'b00000000;
            C <= 1'b0;
            halted_flag <= 1'b0;
        end else if (!halted_flag) begin
            case (instr[7:4])
                4'b0000: ACC <= mem[operand];                  // LOAD
                4'b0001: mem[operand] <= ACC;                  // STORE
                4'b0010: {C, ACC} <= ACC + mem[operand];       // ADD
                4'b0011: begin                                   // SUB
                    {C, ACC} <= ACC - mem[operand];
                    if (ACC > mem[operand]) C <= 1'b0;
                    else C <= 1'b1;
                end
                4'b0100: ACC <= ACC & mem[operand];            // AND
                4'b0101: ACC <= ACC | mem[operand];            // OR
                4'b0110: ACC <= ACC ^ mem[operand];            // XOR
                4'b0111: PC <= operand;                        // JMP
                4'b1000: PC <= (ACC == 8'b00000000) ? operand : PC + 1; // JZ
                4'b1001: PC <= (C == 1'b1) ? operand : PC + 1; // JC
                4'b1010: ACC <= {4'b0000, operand};           // LDI
                4'b1011: begin                                   // SHL
                    C <= ACC[7];
                    ACC <= ACC << 1;
                end
                4'b1100: begin                                   // SHR
                    C <= ACC[0];
                    ACC <= ACC >> 1;
                end
                4'b1101: halted_flag <= 1'b1;                  // HALT
                4'b1110: ;                                      // NOP
                4'b1111: ;                                      // NOP
            endcase
            
            if (instr[7:4] != 4'b0111 && instr[7:4] != 4'b1000 && instr[7:4] != 4'b1001 && instr[7:4] != 4'b1101)
                PC <= (PC + 1) & 4'b1111; // Increment PC and wrap around
        end
    end

endmodule
