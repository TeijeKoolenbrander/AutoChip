// Let us make a brand new microprocessor design together. We're severely
// constrained on space and I/O. We have to fit in 1000 standard cells of an
// ASIC, so I think we will need to restrict ourselves to an accumulator based
// 8-bit architecture with no multi-byte instructions.
//
// We discussed the architecture and froze the following design. Write it as
// a single Verilog module named cpu.
//
// Architecture:
//   - 8-bit accumulator ACC, 4-bit program counter PC, 1-bit carry flag C,
//     and a 1-bit halted flag.
//   - Unified program/data memory of 16 x 8-bit words. It MUST be declared
//     inside the cpu module exactly as:  reg [7:0] mem [0:15];
//     The testbench loads programs by writing this array directly through a
//     hierarchical reference, so the memory must not be cleared or
//     initialized, on reset or otherwise.
//   - Every instruction is one byte: opcode = instr[7:4], operand = instr[3:0].
//     The operand is a memory address, except for LDI where it is an
//     immediate value.
//   - Single-cycle: on each rising clock edge the CPU executes the instruction
//     mem[PC]. Memory reads, both the instruction mem[PC] and the operand
//     mem[operand], are combinational. A STORE writes memory on the rising
//     clock edge.
//   - Read memory only with continuous assign statements, for example
//     assign instr = mem[pc]; reading mem inside an always @(*) block causes a
//     compiler warning that counts as a failure.
//
// Instruction set, where a is the operand:
//   0000 LOAD  a : ACC <- mem[a]
//   0001 STORE a : mem[a] <- ACC
//   0010 ADD   a : ACC <- ACC + mem[a]; C <- carry out of bit 7
//   0011 SUB   a : ACC <- ACC - mem[a]; C <- 1 if ACC < mem[a], meaning a borrow, else 0
//   0100 AND   a : ACC <- ACC & mem[a]
//   0101 OR    a : ACC <- ACC | mem[a]
//   0110 XOR   a : ACC <- ACC ^ mem[a]
//   0111 JMP   a : PC <- a
//   1000 JZ    a : if ACC == 0 then PC <- a, else PC <- PC + 1
//   1001 JC    a : if C == 1 then PC <- a, else PC <- PC + 1
//   1010 LDI   a : ACC <- {4'b0000, a}
//   1011 SHL     : ACC <- ACC << 1; C <- old ACC[7]
//   1100 SHR     : ACC <- ACC >> 1; C <- old ACC[0]
//   1101 HALT    : set halted to 1; PC stays the same
//   1110 NOP     : no operation
//   1111 NOP     : no operation
// Every instruction except JMP, a taken JZ or JC, and HALT sets PC <- PC + 1,
// and PC wraps from 15 to 0. C changes only for ADD, SUB, SHL, and SHR. There
// is no zero flag: JZ tests the current ACC value directly.
//
// Reset: when rst_n is 0, an active-low ASYNCHRONOUS reset, set PC <- 0,
// ACC <- 0, C <- 0, halted <- 0. Reset does not change memory, and memory is
// never written while rst_n is 0.
// While halted is 1, nothing changes on clock edges: no register or memory
// updates until the next reset.
//
// Outputs: acc_out = ACC, pc_out = PC, carry_out = C, halted = the halted flag.

module cpu (
    input        clk,
    input        rst_n,
    output [7:0] acc_out,
    output [3:0] pc_out,
    output       carry_out,
    output       halted
);

endmodule
